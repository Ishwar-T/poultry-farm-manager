# 🐔 Poultry Farm Management System

A full-stack web application to manage poultry farm operations like batches, expenses, sales, daily records, and feed formulas.

---

## 🚀 What it does

👉 Helps farmers:

* Track daily farm activities
* Manage expenses and income
* Monitor bird batches
* Record egg production and mortality
* Manage feed formulas

---

## 🛠 Tech Stack

* Frontend: React (Vite)
* Backend: Spring Boot (Java)
* Database: MySQL

---

## 📦 Features

### 🐔 Batch Management

* Add / Edit / Delete batches
* Track total birds, mortality, breed, start date

### 💸 Expense Tracking

* Add and update expenses
* Category-wise tracking
* Batch-wise expense linking

### 💰 Sales Management

* Record egg / manure / cull sales
* Payment tracking

### 📊 Daily Records

* Track:

  * Eggs produced
  * Feed consumption
  * Mortality
  * Total birds

### 🌾 Feed Formula

* Store and manage feed compositions

---

## 📁 Project Structure

```
src/
 ├── components/
 │    ├── Expense/
 │    ├── Batch/
 │    ├── Sales/
 │    ├── DailyRecord/
 │    ├── Feed/
 │
 ├── pages/
 │    ├── ExpensePage.jsx
 │    ├── BatchPage.jsx
 │    ├── SalesPage.jsx
 │    ├── DailyPage.jsx
 │    ├── FeedPage.jsx
 │
 ├── services/
 │    └── api.js
 │
 └── App.jsx
```

---

## ⚙️ Setup Instructions

### 1️⃣ Clone repo

```bash
git clone <your-repo-link>
cd poultry-farm-management-app
```

---

### 2️⃣ Backend setup (Spring Boot)

* Open backend folder
* Configure database in `application.properties`

```properties
spring.datasource.url=jdbc:mysql://localhost:3306/poultry_db
spring.datasource.username=root
spring.datasource.password=yourpassword
```

Run backend:

```bash
mvn spring-boot:run
```

---

### 3️⃣ Frontend setup (React)

```bash
cd frontend
npm install
npm run dev
```

Open:

```
http://localhost:5173
```

---

## 🔥 Highlights

* Modular architecture (component-based)
* Clean UI with global styling
* Full CRUD operations
* API integration (Spring Boot + React)
* Scalable structure for future features

---

## 🚀 Future Improvements

* Dashboard analytics (profit, trends)
* Graphs & charts 📈
* Mobile responsive UI 📱
* User authentication 🔐
* Cloud deployment 🌍

---

## 👨‍💻 Author

Ishwar Thorat

---

## ⭐ Support

If you like this project, give it a ⭐ on GitHub!
