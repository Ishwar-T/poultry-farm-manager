import React, { useEffect, useState } from "react";
import axios from "axios";

const Dashboard = () => {

  const [totalExpense, setTotalExpense] = useState(0);
  const [totalSales, setTotalSales] = useState(0);
  const [profit, setProfit] = useState(0);
  const [totalBirds, setTotalBirds] = useState(0);

  const fetchData = async () => {
    try {
      const [expRes, salesRes, dailyRes] = await Promise.all([
        axios.get("http://localhost:8080/api/expenses"),
        axios.get("http://localhost:8080/api/sales"),
        axios.get("http://localhost:8080/api/daily-records")
      ]);

      // 🔥 Expense total
      const expenseSum = (expRes.data || []).reduce(
        (sum, e) => sum + (e.amount || 0),
        0
      );

      // 🔥 Sales total
      const salesSum = (salesRes.data || []).reduce(
        (sum, s) => sum + (s.totalAmount || 0),
        0
      );

      // 🔥 Latest birds
      const daily = dailyRes.data || [];
      const latest = daily[daily.length - 1];

      setTotalExpense(expenseSum);
      setTotalSales(salesSum);
      setProfit(salesSum - expenseSum);
      setTotalBirds(latest ? latest.totalBirds : 0);

    } catch (err) {
      console.error("Dashboard error", err);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const cardStyle = {
    flex: 1,
    background: "white",
    padding: 20,
    borderRadius: 10,
    boxShadow: "0 2px 6px rgba(0,0,0,0.1)",
    textAlign: "center"
  };

  return (
    <div>
      <h2>Dashboard</h2>

      <div style={{ display: "flex", gap: 10, marginTop: 20 }}>
        
        <div style={cardStyle}>
          <h3>Total Expense</h3>
          <p>₹ {totalExpense}</p>
        </div>

        <div style={cardStyle}>
          <h3>Total Sales</h3>
          <p>₹ {totalSales}</p>
        </div>

        <div style={cardStyle}>
          <h3>Profit</h3>
          <p style={{ color: profit >= 0 ? "green" : "red" }}>
            ₹ {profit}
          </p>
        </div>

        <div style={cardStyle}>
          <h3>Total Birds</h3>
          <p>{totalBirds}</p>
        </div>

      </div>
    </div>
  );
};

export default Dashboard;